﻿using p_ProveedorStreaming.Clases.strUsuario;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strCuenta
{
    internal class CuentaService
    {
        private List<Cuenta> l_cuentas;
        private Usuario usuario; //Este atributo es temporal,hay que revisar bien el método crear ya que pide un usuario pero este servicio es de la cuenta...
        

        public void Crear(Usuario usuario)
        {
            //Realizar implementación
        }

        //revisar bien los atributos de esta clase ya que se saldria de la logica de cuentaservice 
    }
}
