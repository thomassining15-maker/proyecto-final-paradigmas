﻿using p_ProveedorStreaming.Clases.strContenido.Clases;
using p_ProveedorStreaming.Clases.strUsuario;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strCuenta
{
    internal class Cuenta
    {
        private Usuario usuario;
        private List<Contenido> l_contenidovisto;

        public Cuenta(Usuario usuario)
        {
            this.usuario = usuario;
        }

        public void AgregarContenidoVisto(Contenido contenido)
        {
            //Realizar implementacion para este método
        }
    }
}
