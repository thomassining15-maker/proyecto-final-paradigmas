﻿using p_ProveedorStreaming.Clases.strUsuario;
using p_ProveedorStreaming.Eventos;
using p_ProveedorStreaming.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strJuego.Clases
{
    internal class Juego
    {
        private string nombre;
        private string genero;
        private ulong nro_record;
        private Usuario usuario_record;
        private PublisherNuevoTitulo pub_nuevo_tit;
        private PublisherJuego pub_nuevo_record;

        public Juego(string nombre, string genero)
        {
            this.nombre = nombre;
            this.genero = genero;
        }

        public void ObtenerNuevoRecord(ulong nro_record, Usuario usuario_record, Juego juego, INuevoRecord validador)
        {
            //Implementar logica para este metodo
        }

        public void ObtenerNuevoTitulo(object titulo, INuevoTitulo notificador)
        {
            //Implementar lógica
        }

        //colocar eventhandler´s
    }
}
