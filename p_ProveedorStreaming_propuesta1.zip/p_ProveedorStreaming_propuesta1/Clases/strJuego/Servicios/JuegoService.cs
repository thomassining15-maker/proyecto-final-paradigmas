﻿using p_ProveedorStreaming.Clases.strJuego.Clases;
using p_ProveedorStreaming.Clases.strUsuario;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strJuego.Servicios
{
    internal class JuegoService
    {
        private List<Juego> l_juegos;
        private bool estado_partida;

        public void Agregar(Juego juego)
        {
            //Implementar logica
        }

        public List<Juego> ObtenerTodos()
        {
            //implementar logica
        }

        public Juego BuscarPorNombre(string nombre)
        {
            //implementar logica
        }

        public Juego BuscarPorGenero(string genero)
        {
            //implementar logica
        }

        public ulong ObtenerRecord(string nombre)
        {
            //implementar logica
        }

        public Usuario ObtenerMejorJugador(string nombre)
        {
            //implementar logica
        }

        public string IniciarPartida()
        {
            if (estado_partida == false)
            {
                estado_partida = true;
                return "La partida ha sido iniciada";
            }
            else
            {
                return "La partida ya está en curso";
            }
        }

        public string FinalizarPartida()
        {
            if (estado_partida == true)
            {
                estado_partida = false;
                return "La partida ha finalizado";
            }
            else
            {
                return "La partida ya ha finalizado";
            }
        }
    }
}
