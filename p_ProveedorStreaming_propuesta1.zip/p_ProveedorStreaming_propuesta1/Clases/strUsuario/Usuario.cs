﻿using p_ProveedorStreaming.Eventos;
using p_ProveedorStreaming.Interfaces;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.Marshalling;
using System.Text;

namespace p_ProveedorStreaming.Clases.strUsuario
{
    internal class Usuario
    {
        private Random id_random = new Random();
        private int id_interno;
        private string nombre;
        private DateTime fecha_afilicacion;
        private PublisherCambioCategoria pub_cambio_cat;
        private ReglasNegocioUsuario.l_categorias categoria;
        private ulong puntos;

        public Usuario(string nombre)
        {
            this.id_interno = id_random.Next(ReglasNegocioUsuario.min_id_usuario, ReglasNegocioUsuario.max_id_usuario);
            this.nombre = nombre;
            fecha_afilicacion = DateTime.Now;
        }

        public int ObtenerPuntos()
        {
            //Realizar Implementacion
        }

        public void CambiarCategoria(Usuario usuario, ICambioCategoria logica)
        {
            //Implementar logica
        }

        public void SumarPuntos(int cantidad)
        {
            //RealizarImplementacion
        }

        //falta el event handler
    }
}
