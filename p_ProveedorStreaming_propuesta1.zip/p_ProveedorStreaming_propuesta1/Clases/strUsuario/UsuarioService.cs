﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strUsuario
{
    internal class UsuarioService
    {
    }
}
