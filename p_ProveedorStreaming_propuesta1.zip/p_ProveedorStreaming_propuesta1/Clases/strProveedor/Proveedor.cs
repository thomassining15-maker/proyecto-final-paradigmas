﻿using p_ProveedorStreaming.Clases.strContenido.Clases;
using p_ProveedorStreaming.Clases.strCuenta;
using p_ProveedorStreaming.Clases.strJuego.Clases;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strProveedor
{
    internal class Proveedor
    {
        private string nombre;
        private List<Cuenta> l_cuentas;
        private List<Contenido> l_contenidos;
        private List<Juego> l_juegos;

        public Proveedor(string nombre)
        {
            this.nombre = nombre;
            l_contenidos = new List<Contenido>();
            l_cuentas = new List<Cuenta>;
            l_juegos = new List<Juego>;
        }

        //Implementar validaciones para estos metodos accesores
        internal List<Cuenta> L_cuentas { get => l_cuentas; set => l_cuentas = value; }
        internal List<Contenido> L_contenidos { get => l_contenidos; set => l_contenidos = value; }
        internal List<Juego> L_juegos { get => l_juegos; set => l_juegos = value; }
    }
}