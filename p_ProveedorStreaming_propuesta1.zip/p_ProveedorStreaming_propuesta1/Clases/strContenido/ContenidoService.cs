﻿using p_ProveedorStreaming.Clases.strContenido.Clases;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strContenido
{
    internal class ContenidoService
    {
        private List<Contenido> l_contenidos;

        //No olvidar encontrar un lugar para poder inicializar la lista, un lugar que sea apto para eso
        public void Agregar(Contenido contenido)
        {
            //Realizar implementación
        }

        public List<Contenido> ObtenerTodos()
        {
            return l_contenidos;
        }

        public Contenido ObtenerPorTitulo(string nombre)
        {
            //Realzar implementacion lo voy a dejar retornando null para que no quede error

            return null;
        }
    }
}
