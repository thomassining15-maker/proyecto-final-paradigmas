﻿using p_ProveedorStreaming.Eventos;
using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Clases.strContenido.Clases
{
    internal class Contenido
    {
        private string nombre;
        private PublisherNuevoTitulo pub_nuevo_tit;

        public Contenido(string nombre)
        {
            this.nombre = nombre;
        }
    }
}
