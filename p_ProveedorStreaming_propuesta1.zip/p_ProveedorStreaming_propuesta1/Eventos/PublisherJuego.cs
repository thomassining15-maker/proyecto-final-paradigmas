﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Eventos
{
    internal class PublisherJuego
    {
    }
}
