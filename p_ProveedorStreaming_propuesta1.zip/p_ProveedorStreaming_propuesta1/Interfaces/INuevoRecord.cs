﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Interfaces
{
    internal interface INuevoRecord
    {
        void ObtenerNuevoRecor();
    }
}
