﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Interfaces
{
    internal interface INuevoTitulo
    {
        void ObtenerNuevoTitulo();
    }
}
