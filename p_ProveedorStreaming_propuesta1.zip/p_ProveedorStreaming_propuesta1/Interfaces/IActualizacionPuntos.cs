﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p_ProveedorStreaming.Interfaces
{
    internal interface IActualizacionPuntos
    {
        void Reproducir();
        void ActualizarPuntaje();
    }
}
